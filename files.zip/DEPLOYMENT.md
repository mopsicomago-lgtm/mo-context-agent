# Mo Context Agent — Vercel + Slack Bot Setup

Complete guide to deploy on Vercel and set up Slack integration.

---

## PART 1: VERCEL DEPLOYMENT (Web Agent)

### 1.1 Prerequisites
- Vercel account (free at https://vercel.com)
- Git repository (GitHub/GitLab/Bitbucket)
- Anthropic API key

### 1.2 Setup Git Repository

```bash
# Initialize git
git init
git add .
git commit -m "Initial Mo Context Agent"

# Create GitHub repo and push
git remote add origin https://github.com/your-username/mo-context-agent.git
git push -u origin main
```

### 1.3 Deploy to Vercel

**Option A: Via Vercel CLI (Recommended)**

```bash
npm install -g vercel
vercel login  # Authenticate with Vercel
vercel
```

Follow prompts. Vercel will detect `vercel.json` and deploy.

**Option B: Via Vercel Dashboard**

1. Go to https://vercel.com/dashboard
2. Click "Add New..." → "Project"
3. Select your GitHub repo
4. In "Environment Variables":
   - Name: `ANTHROPIC_API_KEY`
   - Value: `sk-ant-xxxxxxxxxxxxx`
5. Click "Deploy"

### 1.4 Verify Deployment

After deployment, you'll get a URL like:
```
https://mo-context-agent.vercel.app
```

Open in browser → you should see the web form.

### 1.5 Keep INDEX Updated

The agent loads `mo-index.md` locally. To update:

```bash
# Edit mo-index.md locally
nano mo-index.md

# Push changes
git add mo-index.md
git commit -m "Update INDEX"
git push

# Vercel auto-redeploys
```

---

## PART 2: SLACK BOT SETUP

### 2.1 Create Slack App

1. Go to https://api.slack.com/apps
2. Click "Create New App" → "From scratch"
3. App name: `Mo Context`
4. Select your workspace → "Create App"

### 2.2 Configure Slash Command

In "Slash Commands":
1. Click "Create New Command"
2. Command: `/mo`
3. Request URL: `https://your-vercel-url.vercel.app/slack/events`
4. Short description: "Ask Mo's strategic advisor"
5. Save

### 2.3 Enable Events API

In "Event Subscriptions":
1. Toggle "Enable Events"
2. Request URL: `https://your-vercel-url.vercel.app/slack/events`
3. Under "Subscribe to bot events":
   - Add `app_mention`
   - Add `message.im` (direct messages)
4. Save

### 2.4 Get Bot Tokens

In "OAuth & Permissions":
1. Copy "Bot User OAuth Token" → This is `SLACK_BOT_TOKEN`
2. Under "Scopes", ensure:
   - `commands` (for slash commands)
   - `chat:write` (to send messages)
   - `app_mentions:read` (to respond to mentions)

### 2.5 Install App to Workspace

Click "Install to Workspace" → Authorize

---

## PART 3: DEPLOY SLACK BOT TO VERCEL

### 3.1 Update Environment Variables in Vercel

```bash
vercel env add SLACK_BOT_TOKEN
# Paste: xoxb-your-token...

vercel env add SLACK_SIGNING_SECRET
# Found in Slack app "Basic Information" → "Signing Secret"
```

### 3.2 Update Vercel Config for Slack Bot

Edit `vercel.json`:
```json
{
  "version": 2,
  "env": {
    "ANTHROPIC_API_KEY": "@anthropic_api_key",
    "SLACK_BOT_TOKEN": "@slack_bot_token",
    "SLACK_SIGNING_SECRET": "@slack_signing_secret"
  },
  "functions": {
    "slack-bot.js": {
      "memory": 1024,
      "maxDuration": 60
    }
  }
}
```

### 3.3 Update package.json

```json
{
  "scripts": {
    "start": "node agent-vercel.js --web",
    "slack": "node slack-bot.js"
  },
  "dependencies": {
    "@anthropic-ai/sdk": "^0.24.0",
    "@slack/bolt": "^3.12.0",
    "express": "^4.18.2"
  }
}
```

### 3.4 Deploy

```bash
npm install
git add .
git commit -m "Add Slack bot"
git push

# Vercel auto-deploys
```

---

## PART 4: TEST

### Test Web Agent
```
https://mo-context-agent.vercel.app
```

### Test Slack Bot

In your Slack workspace:
```
/mo I want to create a 5-day workshop combining SANA + hypnosis
```

Expected response: Claude responds with full context about SANA, hypnosis frameworks, etc.

---

## PART 5: INDEX SYNC (OPTIONAL ADVANCED)

### Sync Claude Memory ↔ Local FILE

To keep memory in sync:

```bash
# Pull latest INDEX from Claude memory
node sync-index.js pull
# Updates mo-index.md from memory

# Push updated INDEX to memory
node sync-index.js push
# Stores mo-index.md back to memory
```

This ensures both Claude memory and your agent use the latest INDEX.

---

## TROUBLESHOOTING

### Vercel: "ANTHROPIC_API_KEY not found"
- Go to Vercel dashboard → Project → Settings → Environment Variables
- Add `ANTHROPIC_API_KEY` with your key
- Redeploy

### Slack: "Request URL unreachable"
- Ensure Vercel deployment is complete
- Test: `curl https://your-url.vercel.app`
- Check Slack app console for errors

### INDEX not loading
- Verify `mo-index.md` exists in repo root
- Run `git push` to update Vercel
- Wait 30 seconds for rebuild

---

## USAGE IN SLACK

### Slash Command
```
/mo "Create a workshop combining SANA + transactional hypnosis for corporate"
```

### Direct Message
```
@Mo Context Agent I want to pilot L'Identité Qui Manque with 8-12 people
```

### Thread Reply
Just mention `@Mo Context Agent` in any thread

---

## MONITORING

### View Vercel Logs
```bash
vercel logs mo-context-agent
```

### View Slack Bot Logs
In Slack app console → "Activity" tab

---

## SCALE UP (FUTURE)

Once validated:
- Add database for INDEX versioning
- Build admin dashboard to update INDEX
- Integrate with psicomagia.es webhooks
- Add email notifications for important questions

---

## COSTS

- **Vercel**: Free tier (5GB/month)
- **Slack**: Free tier (limited message history)
- **Anthropic API**: Pay-as-you-go (~$0.01 per 1K tokens)

Estimated monthly cost: **$5-10 USD** for light usage

---

Ready to deploy? Run:

```bash
npm install
git push
vercel deploy
```

Then set up Slack, add env vars, and test!
