#!/bin/bash

# Mo Context Agent — Vercel + Slack Quick Setup
# Interactive guide for deployment

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║  Mo Context Agent — Vercel + Slack Deployment  ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════╝${NC}"
echo ""

# Check prerequisites
echo -e "${YELLOW}🔍 Checking prerequisites...${NC}"

if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js not found. Install from https://nodejs.org${NC}"
    exit 1
fi

if ! command -v git &> /dev/null; then
    echo -e "${RED}❌ Git not found. Install from https://git-scm.com${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Node.js $(node -v)${NC}"
echo -e "${GREEN}✅ Git $(git --version | cut -d' ' -f3)${NC}"
echo ""

# Setup menu
echo "What do you want to do?"
echo ""
echo "  1) Setup for LOCAL development (CLI + Web)"
echo "  2) Deploy to VERCEL (cloud)"
echo "  3) Setup SLACK BOT integration"
echo "  4) Full setup (all above)"
echo ""

read -p "Choose (1-4): " choice

case $choice in
    1)
        echo -e "${YELLOW}📦 Installing dependencies...${NC}"
        npm install
        
        echo -e "${YELLOW}📋 Creating .env file...${NC}"
        if [ ! -f .env ]; then
            cp .env.example .env
            echo -e "${YELLOW}⚠️  Edit .env and add ANTHROPIC_API_KEY${NC}"
            echo ""
        fi
        
        echo -e "${GREEN}✅ Ready to run locally${NC}"
        echo ""
        echo "Test it:"
        echo "  node agent-vercel.js --web"
        echo ""
        ;;
        
    2)
        echo -e "${YELLOW}🚀 Setting up Vercel deployment...${NC}"
        
        if ! command -v vercel &> /dev/null; then
            echo -e "${YELLOW}Installing Vercel CLI...${NC}"
            npm install -g vercel
        fi
        
        echo ""
        echo -e "${BLUE}Next steps:${NC}"
        echo "1. Run: ${YELLOW}vercel login${NC}"
        echo "2. Run: ${YELLOW}vercel${NC}"
        echo "3. In Vercel dashboard, add environment variable:"
        echo "   - Name: ANTHROPIC_API_KEY"
        echo "   - Value: sk-ant-xxxxxxxxxxxxx"
        echo "4. Redeploy"
        echo ""
        echo "Ready? Press Enter to continue..."
        read
        
        npm install
        vercel
        
        echo -e "${GREEN}✅ Deployed to Vercel${NC}"
        ;;
        
    3)
        echo -e "${YELLOW}⚙️  Setting up Slack bot...${NC}"
        echo ""
        echo "You need:"
        echo "1. Slack workspace where you have admin access"
        echo "2. Slack app tokens (we'll get them)"
        echo ""
        echo "Follow these steps:"
        echo ""
        echo "1. Go to: https://api.slack.com/apps"
        echo "2. Create New App > From scratch"
        echo "3. Name: Mo Context"
        echo "4. Select workspace"
        echo "5. Copy Bot User OAuth Token → save for later"
        echo "6. Go to Signing Secret → copy that too"
        echo ""
        echo "Once you have tokens, come back here."
        echo ""
        read -p "Ready to add tokens to .env? (y/n) " confirm
        
        if [ "$confirm" = "y" ]; then
            read -p "SLACK_BOT_TOKEN: " slack_token
            read -p "SLACK_SIGNING_SECRET: " slack_secret
            
            echo "" >> .env
            echo "SLACK_BOT_TOKEN=$slack_token" >> .env
            echo "SLACK_SIGNING_SECRET=$slack_secret" >> .env
            
            npm install @slack/bolt
            
            echo -e "${GREEN}✅ Slack bot configured${NC}"
            echo ""
            echo "Test it locally:"
            echo "  npm run slack"
            echo ""
        fi
        ;;
        
    4)
        echo -e "${YELLOW}🔧 Full setup: LOCAL + VERCEL + SLACK${NC}"
        echo ""
        echo "Step 1: Install dependencies"
        npm install
        
        echo ""
        echo -e "${YELLOW}📋 Creating .env...${NC}"
        if [ ! -f .env ]; then
            cp .env.full .env
        fi
        
        echo -e "${YELLOW}Step 2: Add your ANTHROPIC_API_KEY to .env${NC}"
        nano .env
        
        echo ""
        echo -e "${YELLOW}Step 3: Initialize git repo${NC}"
        read -p "Create GitHub repo now? (y/n) " create_repo
        
        if [ "$create_repo" = "y" ]; then
            git init
            git add .
            git commit -m "Initial Mo Context Agent"
            echo "Push to GitHub, then come back for Vercel deploy"
        fi
        
        echo ""
        echo -e "${YELLOW}Step 4: Vercel deployment${NC}"
        read -p "Deploy to Vercel now? (y/n) " deploy
        
        if [ "$deploy" = "y" ]; then
            if ! command -v vercel &> /dev/null; then
                npm install -g vercel
            fi
            vercel
        fi
        
        echo ""
        echo -e "${YELLOW}Step 5: Slack bot${NC}"
        read -p "Setup Slack bot now? (y/n) " setup_slack
        
        if [ "$setup_slack" = "y" ]; then
            read -p "SLACK_BOT_TOKEN: " slack_token
            read -p "SLACK_SIGNING_SECRET: " slack_secret
            
            echo "" >> .env
            echo "SLACK_BOT_TOKEN=$slack_token" >> .env
            echo "SLACK_SIGNING_SECRET=$slack_secret" >> .env
        fi
        
        echo -e "${GREEN}✅ Full setup complete!${NC}"
        echo ""
        ;;
        
    *)
        echo -e "${RED}Invalid choice${NC}"
        exit 1
        ;;
esac

echo ""
echo -e "${BLUE}📖 For detailed instructions, see: DEPLOYMENT.md${NC}"
echo ""
